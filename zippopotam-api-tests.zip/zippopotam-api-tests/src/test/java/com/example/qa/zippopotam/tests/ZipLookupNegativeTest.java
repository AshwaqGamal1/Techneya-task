package com.example.qa.zippopotam.tests;

import com.example.qa.zippopotam.client.ZippopotamClient;
import com.example.qa.zippopotam.data.LookupData;
import com.example.qa.zippopotam.support.ApiAssertions;
import com.example.qa.zippopotam.support.BaseTest;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * How does the endpoint behave when the request is wrong?
 */
public class ZipLookupNegativeTest extends BaseTest {

    @Test(groups = {"smoke", "negative"},
            dataProvider = "notFoundCases", dataProviderClass = LookupData.class,
            description = "Well-formed requests with no matching data return a clean 404")
    public void returnsNotFoundForUnresolvableLookups(String description, String country, String postalCode) {
        Response response = ZippopotamClient.lookup(country, postalCode);

        ApiAssertions.assertResourceNotFound(response);
    }

    @Test(groups = "negative",
            dataProvider = "malformedInput", dataProviderClass = LookupData.class,
            description = "Hostile or malformed input is handled without a server error or information leak")
    public void handlesMalformedInputGracefully(String description, String country, String postalCode) {
        Response response = ZippopotamClient.lookup(country, postalCode);

        ApiAssertions.assertHandledGracefully(response);
    }

    @Test(groups = "negative",
            description = "A missing postal code segment does not return data")
    public void rejectsMissingPostalCode() {
        // Raw path: URL-encoding a blank path param would produce a different request
        // from the one under test.
        ApiAssertions.assertHandledGracefully(ZippopotamClient.getRaw("/us/"));
        ApiAssertions.assertHandledGracefully(ZippopotamClient.getRaw("/us"));
    }

    @Test(groups = "negative",
            description = "A missing country segment does not return data")
    public void rejectsMissingCountry() {
        ApiAssertions.assertHandledGracefully(ZippopotamClient.getRaw("//90210"));
        ApiAssertions.assertHandledGracefully(ZippopotamClient.getRaw("/90210"));
    }

    @Test(groups = "negative",
            description = "Extra path segments are not silently ignored")
    public void rejectsExtraPathSegments() {
        Response response = ZippopotamClient.getRaw("/us/90210/extra");

        ApiAssertions.assertHandledGracefully(response);
    }

    @Test(groups = "negative",
            description = "Unknown query parameters do not change the result")
    public void ignoresUnknownQueryParameters() {
        Response plain = ZippopotamClient.getRaw("/us/90210");
        Response withJunk = ZippopotamClient.getRaw("/us/90210?admin=true&limit=0");

        ApiAssertions.assertSuccessfulLookup(plain);
        ApiAssertions.assertSuccessfulLookup(withJunk);
        assertThat(withJunk.asString())
                .as("Unrecognised query parameters must not influence the response")
                .isEqualTo(plain.asString());
    }
}
