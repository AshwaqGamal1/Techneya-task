package com.example.qa.zippopotam.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.Properties;

/**
 * Single source of truth for environment settings.
 *
 * <p>Resolution order is: JVM system property -> {@code config.properties} -> failure.
 * Putting the system property first is what lets the same suite run against a local
 * mock, a staging host or production without touching the code.
 */
public final class Config {

    private static final String CONFIG_FILE = "config.properties";
    private static final Properties PROPERTIES = load();

    private Config() {
        // static utility
    }

    public static String baseUri() {
        return get("base.uri");
    }

    public static long maxResponseTimeMillis() {
        return getLong("max.response.time.ms");
    }

    public static int connectTimeoutMillis() {
        return (int) getLong("connect.timeout.ms");
    }

    public static int socketTimeoutMillis() {
        return (int) getLong("socket.timeout.ms");
    }

    private static String get(String key) {
        String value = System.getProperty(key, PROPERTIES.getProperty(key));
        if (value == null || value.isBlank()) {
            throw new IllegalStateException(
                    "Missing configuration key '" + key + "'. Set it in " + CONFIG_FILE
                            + " or pass -D" + key + "=<value>.");
        }
        return value.trim();
    }

    private static long getLong(String key) {
        String value = get(key);
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            throw new IllegalStateException(
                    "Configuration key '" + key + "' must be numeric but was '" + value + "'.", e);
        }
    }

    private static Properties load() {
        Properties properties = new Properties();
        try (InputStream in = Config.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (in == null) {
                throw new IllegalStateException(CONFIG_FILE + " not found on the test classpath.");
            }
            properties.load(in);
            return properties;
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to read " + CONFIG_FILE, e);
        }
    }
}
