package com.example.qa.zippopotam.support;

import com.example.qa.zippopotam.model.ZipLookupResponse;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.util.Locale;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Assertions that are reused across test classes, expressed once.
 *
 * <p>The point is that "what a successful lookup looks like" is defined in a single
 * place, so tightening it later is a one-line change rather than an audit of every test.
 */
public final class ApiAssertions {

    private static final int OK = 200;
    private static final int NOT_FOUND = 404;

    /** Strings that should never appear in a response body — they indicate an unhandled error. */
    private static final String[] INTERNAL_LEAK_MARKERS = {
            "Exception", "Traceback", "at java.", "SQLSTATE", "syntax error", "<html"
    };

    private ApiAssertions() {
        // static utility
    }

    public static ZipLookupResponse assertSuccessfulLookup(Response response) {
        assertThat(response.statusCode())
                .as("HTTP status of the lookup")
                .isEqualTo(OK);
        assertThat(ContentType.fromContentType(response.getContentType()))
                .as("Content-Type header was '%s'", response.getContentType())
                .isEqualTo(ContentType.JSON);
        return response.as(ZipLookupResponse.class);
    }

    /**
     * A lookup that cannot be resolved must be a clean 404 — not a 200 with an empty
     * payload, not a 500, and not an error page that leaks server internals.
     *
     * <p>The body itself is checked loosely on purpose: the API is only contractually
     * obliged to say "not found", and pinning the exact empty-body representation would
     * make these tests brittle for no added value.
     */
    public static void assertResourceNotFound(Response response) {
        assertThat(response.statusCode())
                .as("A lookup with no matching data must return 404")
                .isEqualTo(NOT_FOUND);
        assertNoInternalDetailsLeaked(response);
        assertThat(response.asString())
                .as("A 404 body must not carry location data")
                .doesNotContain("place name");
    }

    /** Whatever the outcome, the service must not 5xx or expose its internals. */
    public static void assertHandledGracefully(Response response) {
        assertThat(response.statusCode())
                .as("Malformed input must be handled, not blow up the server")
                .isLessThan(500);
        assertNoInternalDetailsLeaked(response);
    }

    public static void assertNoInternalDetailsLeaked(Response response) {
        String body = response.asString();
        if (body == null || body.isBlank()) {
            return;
        }
        assertThat(Stream.of(INTERNAL_LEAK_MARKERS)
                .filter(marker -> body.toLowerCase(Locale.ROOT).contains(marker.toLowerCase(Locale.ROOT)))
                .toList())
                .as("Response body leaked implementation details: %s", body)
                .isEmpty();
    }
}
