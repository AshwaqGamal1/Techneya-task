package com.example.qa.zippopotam.tests;

import com.example.qa.zippopotam.client.ZippopotamClient;
import com.example.qa.zippopotam.data.LookupCase;
import com.example.qa.zippopotam.data.LookupData;
import com.example.qa.zippopotam.support.ApiAssertions;
import com.example.qa.zippopotam.support.BaseTest;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Does the response keep to its published contract?
 *
 * <p>These are the tests that catch the silent breaking change: a field renamed,
 * latitude switching from string to number, a new required field appearing. The schema
 * uses {@code additionalProperties: false} so an unannounced new field fails loudly and
 * gets a conscious decision, rather than being ignored until a consumer trips over it.
 */
public class ZipLookupContractTest extends BaseTest {

    @Test(groups = {"smoke", "contract"},
            dataProvider = "supportedCountries", dataProviderClass = LookupData.class,
            description = "The response body matches the published JSON schema")
    public void responseMatchesSchema(LookupCase testCase) {
        ZippopotamClient.lookup(testCase.country(), testCase.postalCode())
                .then()
                .statusCode(200)
                .body(matchesJsonSchemaInClasspath("schemas/zip-lookup.json"));
    }

    @Test(groups = "contract",
            description = "A successful response is served as JSON")
    public void servesJsonContentType() {
        Response response = ZippopotamClient.lookup("us", "90210");

        assertThat(ContentType.fromContentType(response.getContentType()))
                .as("Declared Content-Type was '%s'", response.getContentType())
                .isEqualTo(ContentType.JSON);
    }

    @Test(groups = "contract",
            description = "The endpoint is read-only and rejects writes")
    public void rejectsNonReadMethods() {
        Response response = ZippopotamClient.post("us", "90210");

        assertThat(response.statusCode())
                .as("POST to a read-only lookup endpoint must not be accepted")
                .isNotIn(200, 201, 202, 204);
        ApiAssertions.assertHandledGracefully(response);
    }
}
