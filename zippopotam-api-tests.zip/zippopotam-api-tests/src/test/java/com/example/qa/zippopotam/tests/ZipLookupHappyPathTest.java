package com.example.qa.zippopotam.tests;

import com.example.qa.zippopotam.client.ZippopotamClient;
import com.example.qa.zippopotam.data.LookupCase;
import com.example.qa.zippopotam.data.LookupData;
import com.example.qa.zippopotam.model.Place;
import com.example.qa.zippopotam.model.ZipLookupResponse;
import com.example.qa.zippopotam.support.ApiAssertions;
import com.example.qa.zippopotam.support.BaseTest;
import io.restassured.response.Response;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Does a valid lookup return the right data?
 */
public class ZipLookupHappyPathTest extends BaseTest {

    @Test(groups = {"smoke", "functional"},
            dataProvider = "knownUsZipCodes", dataProviderClass = LookupData.class,
            description = "A known US ZIP code returns 200 and the expected location")
    public void returnsExpectedLocationForKnownZipCode(LookupCase testCase) {
        Response response = ZippopotamClient.lookup(testCase.country(), testCase.postalCode());

        ZipLookupResponse body = ApiAssertions.assertSuccessfulLookup(response);

        // Soft assertions: if three fields are wrong, report all three rather than
        // making the reader re-run the suite twice to discover the second and third.
        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(body.postCode())
                    .as("The response must echo the requested postal code")
                    .isEqualTo(testCase.postalCode());
            softly.assertThat(body.countryAbbreviation())
                    .as("Country abbreviation")
                    .isEqualToIgnoringCase(testCase.country());
            softly.assertThat(body.places())
                    .as("Places")
                    .isNotEmpty();
            softly.assertThat(body.places())
                    .extracting(Place::placeName)
                    .as("Expected place name")
                    .contains(testCase.expectedPlaceName());
            softly.assertThat(body.places())
                    .extracting(Place::state)
                    .as("Expected state")
                    .contains(testCase.expectedState());
        });
    }

    @Test(groups = "functional",
            dataProvider = "supportedCountries", dataProviderClass = LookupData.class,
            description = "Each supported country returns a well-formed, non-empty result")
    public void returnsDataForEverySupportedCountry(LookupCase testCase) {
        Response response = ZippopotamClient.lookup(testCase.country(), testCase.postalCode());

        ZipLookupResponse body = ApiAssertions.assertSuccessfulLookup(response);

        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(body.countryAbbreviation())
                    .as("Country abbreviation must match the country requested")
                    .isEqualToIgnoringCase(testCase.country());
            softly.assertThat(body.country())
                    .as("Country name must be populated")
                    .isNotBlank();
            softly.assertThat(body.places())
                    .as("At least one place must be returned")
                    .isNotEmpty();
            softly.assertThat(body.places())
                    .as("Every place must have a name")
                    .allSatisfy(place -> assertThat(place.placeName()).isNotBlank());
        });
    }

    @Test(groups = "functional",
            description = "The country code is treated case-insensitively")
    public void treatsCountryCodeAsCaseInsensitive() {
        Response lowerCase = ZippopotamClient.lookup("us", "90210");
        Response upperCase = ZippopotamClient.lookup("US", "90210");

        ApiAssertions.assertSuccessfulLookup(lowerCase);
        ApiAssertions.assertSuccessfulLookup(upperCase);

        assertThat(upperCase.as(ZipLookupResponse.class))
                .as("Casing of the country segment must not change the result")
                .isEqualTo(lowerCase.as(ZipLookupResponse.class));
    }

    @Test(groups = "functional",
            description = "A trailing slash resolves to the same resource")
    public void treatsTrailingSlashAsEquivalent() {
        Response withoutSlash = ZippopotamClient.getRaw("/us/90210");
        Response withSlash = ZippopotamClient.getRaw("/us/90210/");

        ApiAssertions.assertSuccessfulLookup(withoutSlash);
        ApiAssertions.assertSuccessfulLookup(withSlash);

        assertThat(withSlash.as(ZipLookupResponse.class))
                .as("The documented URL structure includes a trailing slash, so both forms "
                        + "must return the same resource")
                .isEqualTo(withoutSlash.as(ZipLookupResponse.class));
    }

    @Test(groups = "functional",
            description = "Repeated identical requests return identical data (GET is idempotent)")
    public void returnsStableResultsAcrossRepeatedRequests() {
        ZipLookupResponse first = ZippopotamClient.lookup("us", "90210").as(ZipLookupResponse.class);
        ZipLookupResponse second = ZippopotamClient.lookup("us", "90210").as(ZipLookupResponse.class);

        assertThat(second)
                .as("A read-only endpoint must not return different data between calls")
                .isEqualTo(first);
    }
}
