package com.example.qa.zippopotam.tests;

import com.example.qa.zippopotam.client.ZippopotamClient;
import com.example.qa.zippopotam.data.LookupCase;
import com.example.qa.zippopotam.data.LookupData;
import com.example.qa.zippopotam.model.Place;
import com.example.qa.zippopotam.model.ZipLookupResponse;
import com.example.qa.zippopotam.support.ApiAssertions;
import com.example.qa.zippopotam.support.BaseTest;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Is the data itself sane, beyond simply being the right shape?
 *
 * <p>A schema proves latitude is a numeric string; it does not prove it is a latitude.
 * These checks are the difference between "the API responded" and "the API is correct".
 */
public class ZipLookupDataIntegrityTest extends BaseTest {

    @Test(groups = "functional",
            dataProvider = "supportedCountries", dataProviderClass = LookupData.class,
            description = "Coordinates fall inside the valid geographic range")
    public void returnsPlausibleCoordinates(LookupCase testCase) {
        ZipLookupResponse body = ApiAssertions.assertSuccessfulLookup(
                ZippopotamClient.lookup(testCase.country(), testCase.postalCode()));

        SoftAssertions.assertSoftly(softly -> body.places().forEach(place -> {
            softly.assertThat(place.latitudeAsDouble())
                    .as("Latitude of '%s'", place.placeName())
                    .isBetween(-90.0, 90.0);
            softly.assertThat(place.longitudeAsDouble())
                    .as("Longitude of '%s'", place.placeName())
                    .isBetween(-180.0, 180.0);
        }));
    }

    @Test(groups = "functional",
            description = "Coordinates for a known ZIP code point at the right part of the world")
    public void returnsCoordinatesInTheExpectedRegion() {
        // Beverly Hills: roughly 34.09 N, 118.41 W. A one-degree box is tight enough to
        // catch swapped lat/long or a sign error, loose enough to survive a data refresh.
        Place place = ApiAssertions.assertSuccessfulLookup(ZippopotamClient.lookup("us", "90210"))
                .places()
                .get(0);

        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(place.latitudeAsDouble()).as("Latitude").isBetween(33.5, 34.5);
            softly.assertThat(place.longitudeAsDouble()).as("Longitude").isBetween(-119.0, -118.0);
        });
    }

    @Test(groups = "functional",
            description = "A postal code covering several localities returns all of them, without duplicates")
    public void returnsDistinctPlacesForMultiPlacePostalCodes() {
        // German PLZ 46049 (Oberhausen) and many others map to more than one locality;
        // whichever the dataset returns, the list must not contain repeats.
        ZipLookupResponse body = ApiAssertions.assertSuccessfulLookup(
                ZippopotamClient.lookup("de", "46049"));

        assertThat(body.places())
                .as("Duplicate place entries would double-count results for a consumer")
                .doesNotHaveDuplicates()
                .isNotEmpty();
    }

    @Test(groups = "functional",
            description = "Text fields are trimmed and free of placeholder values")
    public void returnsCleanTextFields() {
        ZipLookupResponse body = ApiAssertions.assertSuccessfulLookup(
                ZippopotamClient.lookup("us", "90210"));

        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(body.country()).as("Country").isEqualTo(body.country().trim());
            body.places().forEach(place -> {
                softly.assertThat(place.placeName())
                        .as("Place name")
                        .isEqualTo(place.placeName().trim())
                        .isNotEqualToIgnoringCase("null")
                        .isNotEqualTo("N/A");
                softly.assertThat(place.state()).as("State").isNotBlank();
            });
        });
    }
}
