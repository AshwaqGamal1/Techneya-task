package com.example.qa.zippopotam.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Deserialised body of GET /{country}/{postalCode}.
 *
 * <p>Deserialising rather than reading JSON paths keeps the tests readable
 * ({@code response.places().get(0).placeName()}) and makes a renamed field a compile
 * or mapping failure in one file instead of a string typo scattered across tests.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ZipLookupResponse(
        @JsonProperty("post code") String postCode,
        @JsonProperty("country") String country,
        @JsonProperty("country abbreviation") String countryAbbreviation,
        @JsonProperty("places") List<Place> places) {
}
