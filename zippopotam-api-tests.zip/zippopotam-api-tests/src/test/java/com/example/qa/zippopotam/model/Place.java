package com.example.qa.zippopotam.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * One location returned for a postal code.
 *
 * <p>The API returns coordinates as strings, so the model keeps them as strings and
 * exposes typed accessors. Silently coercing them in the model would hide a real
 * contract change (string -> number) that a consumer would care about.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record Place(
        @JsonProperty("place name") String placeName,
        @JsonProperty("longitude") String longitude,
        @JsonProperty("latitude") String latitude,
        @JsonProperty("state") String state,
        @JsonProperty("state abbreviation") String stateAbbreviation) {

    public double latitudeAsDouble() {
        return parse(latitude, "latitude");
    }

    public double longitudeAsDouble() {
        return parse(longitude, "longitude");
    }

    private double parse(String value, String field) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException | NullPointerException e) {
            throw new AssertionError(
                    "Place '" + placeName + "' returned a non-numeric " + field + ": " + value, e);
        }
    }
}
