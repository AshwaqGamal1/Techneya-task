package com.example.qa.zippopotam.support;

import com.example.qa.zippopotam.config.Config;
import io.restassured.RestAssured;
import org.testng.annotations.BeforeSuite;

/**
 * One-time REST Assured configuration for the whole suite.
 *
 * <p>Test classes extend this and nothing else — there is no shared mutable state here,
 * which is what allows the suite to run methods in parallel.
 */
public abstract class BaseTest {

    @BeforeSuite(alwaysRun = true)
    public void configureRestAssured() {
        // Quiet on success, full request+response dump on failure. This is the single
        // most useful debugging setting in an API suite.
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
        System.out.printf("Running Zippopotam suite against %s%n", Config.baseUri());
    }
}
