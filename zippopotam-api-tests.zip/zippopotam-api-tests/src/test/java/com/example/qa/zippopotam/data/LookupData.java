package com.example.qa.zippopotam.data;

import org.testng.annotations.DataProvider;

/**
 * All test data in one place, separated from the test logic.
 *
 * <p>Known-value expectations are only asserted where the reference data is genuinely
 * stable and well known (US ZIP codes). For other countries the tests assert the
 * contract — 200, correct country abbreviation, at least one place — rather than
 * hard-coding place names from a dataset that is maintained by a third party. Tests
 * that fail because upstream renamed a Dutch village are noise, not signal.
 */
public final class LookupData {

    private LookupData() {
        // static utility
    }

    @DataProvider(name = "knownUsZipCodes")
    public static Object[][] knownUsZipCodes() {
        return new Object[][]{
                {new LookupCase("Beverly Hills", "us", "90210", "Beverly Hills", "California")},
                {new LookupCase("Manhattan", "us", "10001", "New York", "New York")},
                {new LookupCase("Leading-zero ZIP", "us", "01001", "Agawam", "Massachusetts")},
        };
    }

    @DataProvider(name = "supportedCountries")
    public static Object[][] supportedCountries() {
        return new Object[][]{
                {LookupCase.shapeOnly("US numeric ZIP", "us", "90210")},
                {LookupCase.shapeOnly("Canadian forward sortation area", "ca", "M5V")},
                {LookupCase.shapeOnly("German PLZ", "de", "01067")},
                {LookupCase.shapeOnly("Spanish código postal", "es", "28001")},
                {LookupCase.shapeOnly("Dutch postcode", "nl", "1011")},
                {LookupCase.shapeOnly("GB outward code", "gb", "B1")},
        };
    }

    /**
     * Well-formed requests that should simply have no data behind them.
     */
    @DataProvider(name = "notFoundCases")
    public static Object[][] notFoundCases() {
        return new Object[][]{
                {"Unassigned US ZIP", "us", "99999"},
                {"Unsupported country code", "zz", "90210"},
                {"Valid ZIP against wrong country", "de", "90210"},
                {"Letters in a numeric-only country", "us", "ABCDE"},
                {"Too few digits", "us", "9021"},
                {"Too many digits", "us", "902100"},
                {"ZIP+4 extension", "us", "90210-1234"},
                {"Negative number", "us", "-90210"},
        };
    }

    /**
     * Hostile or malformed input. The expectation is "handled" (4xx, no stack trace),
     * not any particular status code — pinning that down would be guessing at a
     * contract the API never promised.
     */
    @DataProvider(name = "malformedInput")
    public static Object[][] malformedInput() {
        return new Object[][]{
                {"SQL injection attempt", "us", "90210' OR '1'='1"},
                {"Script injection attempt", "us", "<script>alert(1)</script>"},
                {"Path traversal attempt", "us", "../../etc/passwd"},
                {"Unicode input", "us", "９０２１０"},
                {"Very long postal code", "us", "9".repeat(2048)},
                {"Whitespace only", "us", "   "},
        };
    }
}
