package com.example.qa.zippopotam.data;

/**
 * A single lookup and what we expect back. Named fields beat {@code Object[]} rows:
 * the TestNG report shows the record's toString, so a failure says exactly which case
 * broke without opening the data provider.
 */
public record LookupCase(
        String description,
        String country,
        String postalCode,
        String expectedPlaceName,
        String expectedState) {

    /** For cases where only the shape of the response matters, not the specific data. */
    public static LookupCase shapeOnly(String description, String country, String postalCode) {
        return new LookupCase(description, country, postalCode, null, null);
    }

    @Override
    public String toString() {
        return "%s [%s/%s]".formatted(description, country, postalCode);
    }
}
