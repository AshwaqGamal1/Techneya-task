package com.example.qa.zippopotam.tests;

import com.example.qa.zippopotam.client.ZippopotamClient;
import com.example.qa.zippopotam.config.Config;
import com.example.qa.zippopotam.support.ApiAssertions;
import com.example.qa.zippopotam.support.BaseTest;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Cheap non-functional guards, kept in their own group so they can be excluded from
 * pipelines where a shared runner would make timings meaningless.
 *
 * <p>This is not performance testing — a single-threaded Java test cannot tell you
 * about throughput. It is a tripwire for the day a lookup starts taking three seconds.
 */
public class ZipLookupNonFunctionalTest extends BaseTest {

    @Test(groups = "non-functional",
            description = "A single lookup responds within the configured budget")
    public void respondsWithinResponseTimeBudget() {
        Response response = ZippopotamClient.lookup("us", "90210");

        ApiAssertions.assertSuccessfulLookup(response);
        assertThat(response.time())
                .as("Response time budget is configurable via -Dmax.response.time.ms")
                .isLessThanOrEqualTo(Config.maxResponseTimeMillis());
    }

    @Test(groups = "non-functional",
            description = "The endpoint is served over HTTPS")
    public void isServedOverHttps() {
        assertThat(Config.baseUri())
                .as("Location lookups should not travel over plain HTTP")
                .startsWith("https://");
    }

    @Test(groups = "non-functional",
            description = "Responses carry no obvious server fingerprinting headers")
    public void doesNotAdvertiseServerInternals() {
        Response response = ZippopotamClient.lookup("us", "90210");

        assertThat(response.getHeader("X-Powered-By"))
                .as("X-Powered-By tells an attacker what to target")
                .isNull();
    }
}
