package com.example.qa.zippopotam.client;

import com.example.qa.zippopotam.config.Config;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;

/**
 * The only place in the suite that knows the shape of the Zippopotam URL.
 *
 * <p>Tests talk in terms of "look up this country and postal code"; if the path ever
 * becomes {@code /v2/{country}/{postalCode}} or gains an API key header, this class is
 * the single edit. Nothing here asserts — an API client that validates would make it
 * impossible to write negative tests against it.
 */
public final class ZippopotamClient {

    private static final String LOOKUP_PATH = "/{country}/{postalCode}";

    private static final RequestSpecification DEFAULT_SPEC = new RequestSpecBuilder()
            .setBaseUri(Config.baseUri())
            .setAccept(ContentType.JSON)
            .setConfig(RestAssuredConfig.config().httpClient(HttpClientConfig.httpClientConfig()
                    .setParam("http.connection.timeout", Config.connectTimeoutMillis())
                    .setParam("http.socket.timeout", Config.socketTimeoutMillis())))
            // Logged at URI/STATUS level so CI output stays readable; the base test
            // class turns on full logging for failures only.
            .addFilter(new RequestLoggingFilter(LogDetail.URI))
            .addFilter(new ResponseLoggingFilter(LogDetail.STATUS))
            .build();

    private ZippopotamClient() {
        // static utility
    }

    /**
     * GET /{country}/{postalCode} with both segments URL-encoded.
     */
    public static Response lookup(String country, String postalCode) {
        return given()
                .spec(DEFAULT_SPEC)
                .pathParam("country", country)
                .pathParam("postalCode", postalCode)
                .when()
                .get(LOOKUP_PATH);
    }

    /**
     * GET against a raw path with URL encoding switched off.
     *
     * <p>Needed for the malformed-request tests: encoding would turn {@code /us/} into
     * something the server never sees as a malformed path, which is exactly the case
     * being tested.
     */
    public static Response getRaw(String rawPath) {
        return given()
                .spec(DEFAULT_SPEC)
                .urlEncodingEnabled(false)
                .when()
                .get(rawPath);
    }

    /**
     * POST to the lookup path — used to check that a read-only endpoint rejects writes.
     */
    public static Response post(String country, String postalCode) {
        return given()
                .spec(DEFAULT_SPEC)
                .contentType(ContentType.JSON)
                .pathParam("country", country)
                .pathParam("postalCode", postalCode)
                .body("{}")
                .when()
                .post(LOOKUP_PATH);
    }
}
