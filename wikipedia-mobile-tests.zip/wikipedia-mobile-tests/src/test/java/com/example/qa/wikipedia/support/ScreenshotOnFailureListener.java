package com.example.qa.wikipedia.support;

import com.example.qa.wikipedia.driver.DriverManager;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Captures a screenshot and the page source when a test fails.
 *
 * <p>On mobile these two artefacts answer nearly every "why did it fail on CI but not on
 * my machine" question: the screenshot shows what was on screen, the page source shows
 * whether the element was there under a different identifier.
 */
public class ScreenshotOnFailureListener implements ITestListener {

    private static final Path ARTIFACT_DIR = Path.of("target", "failures");
    private static final DateTimeFormatter STAMP =
            DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    @Override
    public void onTestFailure(ITestResult result) {
        if (!DriverManager.hasSession()) {
            return;
        }
        String name = result.getMethod().getMethodName() + "-" + LocalDateTime.now().format(STAMP);
        try {
            Files.createDirectories(ARTIFACT_DIR);
            byte[] screenshot = ((TakesScreenshot) DriverManager.driver())
                    .getScreenshotAs(OutputType.BYTES);
            Files.write(ARTIFACT_DIR.resolve(name + ".png"), screenshot);
            Files.writeString(ARTIFACT_DIR.resolve(name + ".xml"),
                    DriverManager.driver().getPageSource());
            System.out.println("Failure artefacts written to " + ARTIFACT_DIR.resolve(name));
        } catch (IOException | RuntimeException e) {
            // Never let diagnostics failure mask the actual test failure.
            System.err.println("Could not capture failure artefacts: " + e.getMessage());
        }
    }
}
