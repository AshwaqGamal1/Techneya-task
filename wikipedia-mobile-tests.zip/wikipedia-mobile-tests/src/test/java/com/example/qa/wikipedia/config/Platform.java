package com.example.qa.wikipedia.config;

import java.util.Arrays;
import java.util.Locale;

public enum Platform {

    ANDROID,
    IOS;

    public static Platform from(String value) {
        return Arrays.stream(values())
                .filter(p -> p.name().equalsIgnoreCase(value))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "Unsupported platform '" + value + "'. Expected one of "
                                + Arrays.toString(values()).toLowerCase(Locale.ROOT)));
    }

    public boolean isAndroid() {
        return this == ANDROID;
    }
}
