package com.example.qa.wikipedia.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.time.Duration;
import java.util.Locale;
import java.util.Properties;

/**
 * Single source of truth for run configuration.
 *
 * <p>Resolution order is system property -> {@code config.properties} -> failure. That
 * ordering is what lets the same suite run on a local emulator, a colleague's physical
 * device and a cloud grid without a code change.
 */
public final class Config {

    private static final String CONFIG_FILE = "config.properties";
    private static final Properties PROPERTIES = load();

    private Config() {
    }

    public static Platform platform() {
        return Platform.from(get("platform"));
    }

    public static String appiumServerUrl() {
        return get("appium.server.url");
    }

    public static Duration waitTimeout() {
        return Duration.ofSeconds(Long.parseLong(get("wait.timeout")));
    }

    public static Duration shortWaitTimeout() {
        return Duration.ofSeconds(Long.parseLong(get("wait.short.timeout")));
    }

    /**
     * Reads a key for the platform under test, e.g. {@code deviceName()} resolves to
     * {@code android.device.name} or {@code ios.device.name}.
     */
    public static String forPlatform(String key) {
        return get(platform().name().toLowerCase(Locale.ROOT) + "." + key);
    }

    public static String forPlatformOrEmpty(String key) {
        String value = System.getProperty(key,
                PROPERTIES.getProperty(platform().name().toLowerCase(Locale.ROOT) + "." + key));
        return value == null ? "" : value.trim();
    }

    private static String get(String key) {
        String value = System.getProperty(key, PROPERTIES.getProperty(key));
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("Missing configuration key '" + key
                    + "'. Set it in " + CONFIG_FILE + " or pass -D" + key + "=<value>.");
        }
        return value.trim();
    }

    private static Properties load() {
        Properties properties = new Properties();
        try (InputStream in = Config.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (in == null) {
                throw new IllegalStateException(CONFIG_FILE + " not found on the test classpath.");
            }
            properties.load(in);
            return properties;
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to read " + CONFIG_FILE, e);
        }
    }
}
