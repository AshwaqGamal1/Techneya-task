package com.example.qa.wikipedia.support;

import com.example.qa.wikipedia.config.Config;
import com.example.qa.wikipedia.driver.DriverManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;

/**
 * Session per test method.
 *
 * <p>Per-method rather than per-class: a UI test that inherits app state from the
 * previous test is a test that passes for reasons you cannot see. The cost is startup
 * time, which is the right trade for a suite this size.
 */
@Listeners(ScreenshotOnFailureListener.class)
public abstract class BaseTest {

    @BeforeMethod(alwaysRun = true)
    public void startSession() {
        System.out.printf("Starting %s session against %s%n",
                Config.platform(), Config.appiumServerUrl());
        DriverManager.startSession();
    }

    @AfterMethod(alwaysRun = true)
    public void endSession() {
        // alwaysRun so a failed test still releases the device. A leaked session blocks
        // the next run on the same emulator.
        DriverManager.quitSession();
    }
}
