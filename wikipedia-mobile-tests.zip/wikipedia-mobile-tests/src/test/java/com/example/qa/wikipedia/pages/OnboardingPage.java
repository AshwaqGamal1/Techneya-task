package com.example.qa.wikipedia.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;

/**
 * The first-run carousel. Only shown on a fresh install, which is exactly why it is
 * modelled: the suite resets the app between runs, so it is shown every time locally
 * and never on a device where someone has already opened the app by hand.
 */
public class OnboardingPage extends BasePage {

    @AndroidFindBy(id = "org.wikipedia:id/fragment_onboarding_skip_button")
    @iOSXCUITFindBy(accessibility = "Skip")
    private WebElement skipButton;

    /**
     * @return the Explore feed, whether or not onboarding needed dismissing
     */
    public ExploreFeedPage skipIfPresent() {
        if (isDisplayed(skipButton)) {
            tap(skipButton);
        }
        return new ExploreFeedPage();
    }

    @Override
    protected WebElement uniqueElement() {
        return skipButton;
    }
}
