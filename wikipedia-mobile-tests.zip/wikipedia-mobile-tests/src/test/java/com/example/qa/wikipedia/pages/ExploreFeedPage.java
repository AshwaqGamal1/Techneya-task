package com.example.qa.wikipedia.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;

/**
 * The app's landing screen. Its only jobs here are proving the app launched and getting
 * us into search and into the saved articles tab.
 */
public class ExploreFeedPage extends BasePage {

    @AndroidFindBy(id = "org.wikipedia:id/search_container")
    @iOSXCUITFindBy(accessibility = "Search Wikipedia")
    private WebElement searchBar;

    @AndroidFindBy(id = "org.wikipedia:id/nav_tab_reading_lists")
    @iOSXCUITFindBy(accessibility = "Saved")
    private WebElement savedTab;

    public ExploreFeedPage() {
        waitUntilLoaded();
    }

    public SearchPage openSearch() {
        tap(searchBar);
        return new SearchPage();
    }

    public ReadingListsPage openReadingLists() {
        tap(savedTab);
        return new ReadingListsPage();
    }

    @Override
    protected WebElement uniqueElement() {
        return searchBar;
    }
}
