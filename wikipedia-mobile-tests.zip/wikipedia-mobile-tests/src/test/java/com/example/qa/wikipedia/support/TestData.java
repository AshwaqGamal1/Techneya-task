package com.example.qa.wikipedia.support;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class TestData {

    public static final String ARTICLE_TITLE = "Artificial intelligence";

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("HHmmss-SSS");

    private TestData() {
    }

    /**
     * A list name that cannot collide with a previous run.
     *
     * <p>Reusing a fixed name would make the test pass on a device where the list
     * already exists even if creation is broken — and fail on the second run when the
     * app rejects the duplicate.
     */
    public static String uniqueReadingListName() {
        return "Automation " + LocalDateTime.now().format(STAMP);
    }
}
