package com.example.qa.wikipedia.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;

/**
 * The sheet that lets a saved article be filed into a named list.
 *
 * <p>Saving in the Wikipedia app is two steps in one gesture: the tap bookmarks the
 * article, and a snackbar then offers "Add to list". This object owns that whole
 * interaction so the test reads as one intent rather than three taps.
 */
public class AddToReadingListDialog extends BasePage {

    @AndroidFindBy(id = "org.wikipedia:id/snackbar_action")
    @iOSXCUITFindBy(accessibility = "Add to list")
    private WebElement snackbarAddToListAction;

    @AndroidFindBy(id = "org.wikipedia:id/create_button")
    @iOSXCUITFindBy(accessibility = "Create a new list")
    private WebElement createNewListButton;

    @AndroidFindBy(id = "org.wikipedia:id/text_input")
    @iOSXCUITFindBy(className = "XCUIElementTypeTextField")
    private WebElement listNameInput;

    @AndroidFindBy(id = "android:id/button1")
    @iOSXCUITFindBy(accessibility = "Create")
    private WebElement confirmButton;

    public AddToReadingListDialog() {
        openFromSnackbarIfNeeded();
        waitUntilLoaded();
    }

    /**
     * Creates a list with the given name and files the current article into it.
     *
     * @return the article screen, which the app returns to once the list is created
     */
    public ArticlePage createNewList(String name, String articleTitle) {
        tap(createNewListButton);
        type(listNameInput, name);
        hideKeyboardIfShown();
        tap(confirmButton);
        return new ArticlePage(articleTitle);
    }

    private void openFromSnackbarIfNeeded() {
        // The snackbar is transient. If it has already faded, the sheet is reached by
        // tapping Save again, which the app treats as "edit where this is saved".
        if (isDisplayed(snackbarAddToListAction)) {
            tap(snackbarAddToListAction);
        }
    }

    @Override
    protected WebElement uniqueElement() {
        return createNewListButton;
    }
}
