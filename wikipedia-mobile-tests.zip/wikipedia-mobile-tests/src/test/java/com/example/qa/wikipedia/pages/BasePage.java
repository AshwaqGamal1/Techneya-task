package com.example.qa.wikipedia.pages;

import com.example.qa.wikipedia.config.Config;
import com.example.qa.wikipedia.driver.DriverManager;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Map;

/**
 * Shared behaviour for every page object: explicit waits, safe interactions, scrolling.
 *
 * <p>No {@code Thread.sleep} anywhere in this project. Mobile UIs animate, and the fix
 * for a flaky tap is an explicit condition, not a longer sleep — a sleep that is long
 * enough on a fast laptop is still too short on a loaded CI machine.
 */
public abstract class BasePage {

    protected final AppiumDriver driver;
    private final WebDriverWait wait;
    private final WebDriverWait shortWait;

    protected BasePage() {
        this.driver = DriverManager.driver();
        this.wait = new WebDriverWait(driver, Config.waitTimeout());
        this.shortWait = new WebDriverWait(driver, Config.shortWaitTimeout());
        // Zero implicit wait on the decorator: mixing implicit and explicit waits
        // produces unpredictable timeouts. Everything here waits explicitly.
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ZERO), this);
    }

    /** Every page declares how to recognise itself; used to fail fast with a clear message. */
    protected abstract WebElement uniqueElement();

    protected void waitUntilLoaded() {
        try {
            wait.until(ExpectedConditions.visibilityOf(uniqueElement()));
        } catch (TimeoutException e) {
            throw new AssertionError(
                    getClass().getSimpleName() + " did not load within " + Config.waitTimeout(), e);
        }
    }

    protected WebElement waitForVisible(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    /** Generic explicit wait, for conditions the canned {@code ExpectedConditions} do not cover. */
    protected <T> T waitFor(java.util.function.Function<org.openqa.selenium.WebDriver, T> condition,
                            String description) {
        try {
            return wait.until(condition);
        } catch (TimeoutException e) {
            throw new AssertionError("Timed out waiting for " + description, e);
        }
    }

    protected void tap(WebElement element) {
        wait.until(ExpectedConditions.elementToBeClickable(element)).click();
    }

    protected void type(WebElement field, String text) {
        WebElement visible = waitForVisible(field);
        visible.clear();
        visible.sendKeys(text);
    }

    /**
     * Presence check bounded by the short timeout — used for genuinely optional UI such
     * as onboarding, which appears on a first install and never again.
     */
    protected boolean isDisplayed(WebElement element) {
        try {
            shortWait.until(ExpectedConditions.visibilityOf(element));
            return true;
        } catch (TimeoutException | NoSuchElementException e) {
            return false;
        }
    }

    protected boolean isDisplayed(By locator) {
        try {
            shortWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            return true;
        } catch (TimeoutException | NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Scrolls a list until an element with the given visible text is on screen.
     *
     * <p>Platform-specific by necessity: UiAutomator and XCUITest expose different
     * native scrolling. Keeping that split here means no page object has to care.
     */
    protected WebElement scrollToText(String text) {
        if (Config.platform().isAndroid()) {
            return driver.findElement(AppiumBy.androidUIAutomator(
                    "new UiScrollable(new UiSelector().scrollable(true))"
                            + ".scrollIntoView(new UiSelector().textContains(\"" + text + "\"))"));
        }
        driver.executeScript("mobile: scroll", Map.of("direction", "down", "name", text));
        return driver.findElement(AppiumBy.iOSNsPredicateString(
                "label CONTAINS[c] '" + text + "'"));
    }

    /**
     * Back navigation. Android has a hardware back key; iOS has a navigation bar button,
     * so the two are genuinely different actions rather than one API.
     */
    protected void pressBack() {
        if (Config.platform().isAndroid()) {
            driver.navigate().back();
            return;
        }
        driver.findElement(AppiumBy.iOSClassChain(
                "**/XCUIElementTypeNavigationBar/**/XCUIElementTypeButton[1]")).click();
    }

    protected void hideKeyboardIfShown() {        try {
            if (driver instanceof io.appium.java_client.HidesKeyboard keyboard) {
                keyboard.hideKeyboard();
            }
        } catch (RuntimeException ignored) {
            // The keyboard was not open. Not worth failing a test over.
        }
    }
}
