package com.example.qa.wikipedia.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;

/**
 * An opened article.
 *
 * <p>The article body is a WebView, so this page object deliberately only touches the
 * native chrome around it (the bottom action bar). Dropping into WebView context to read
 * article text would make the test slower and far more brittle for no gain — the
 * scenario is about saving, not about rendering.
 */
public class ArticlePage extends BasePage {

    @AndroidFindBy(accessibility = "Save")
    @iOSXCUITFindBy(accessibility = "Save for later")
    private WebElement saveButton;

    @AndroidFindBy(id = "org.wikipedia:id/page_toolbar")
    @iOSXCUITFindBy(className = "XCUIElementTypeNavigationBar")
    private WebElement toolbar;

    private final String title;

    public ArticlePage(String title) {
        this.title = title;
        waitUntilLoaded();
    }

    public String title() {
        return title;
    }

    /**
     * Taps Save. In the Wikipedia app this bookmarks the article into the default list
     * and offers "Add to list" in a snackbar, which is the route to a custom list.
     */
    public AddToReadingListDialog saveAndChooseList() {
        tap(saveButton);
        return new AddToReadingListDialog();
    }

    /** Returns to the Explore feed, from where the Saved tab is reachable. */
    public ExploreFeedPage goBackToFeed() {
        pressBack();
        return new ExploreFeedPage();
    }

    @Override
    protected WebElement uniqueElement() {
        return toolbar;
    }
}
