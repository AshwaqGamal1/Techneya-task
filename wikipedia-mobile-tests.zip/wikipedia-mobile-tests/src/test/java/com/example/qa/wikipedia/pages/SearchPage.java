package com.example.qa.wikipedia.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;

import java.util.List;

public class SearchPage extends BasePage {

    @AndroidFindBy(id = "org.wikipedia:id/search_src_text")
    @iOSXCUITFindBy(className = "XCUIElementTypeSearchField")
    private WebElement searchInput;

    @AndroidFindBy(id = "org.wikipedia:id/search_results_list")
    @iOSXCUITFindBy(accessibility = "Search results")
    private WebElement resultsList;

    @AndroidFindBy(id = "org.wikipedia:id/page_list_item_title")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCell/**/XCUIElementTypeStaticText[1]")
    private List<WebElement> resultTitles;

    public SearchPage() {
        waitUntilLoaded();
    }

    public SearchPage searchFor(String term) {
        type(searchInput, term);
        waitForVisible(resultsList);
        waitFor(d -> !resultTitles.isEmpty(), "search results for '" + term + "'");
        return this;
    }

    /**
     * Opens the first result whose title matches exactly.
     *
     * <p>Exact match rather than "first result": Wikipedia search returns related
     * articles too, and a test that blindly taps position one silently starts asserting
     * against a different article the day relevance ranking changes.
     */
    public ArticlePage openResult(String title) {
        WebElement match = waitFor(
                d -> resultTitles.stream()
                        .filter(element -> title.equalsIgnoreCase(element.getText().trim()))
                        .findFirst()
                        .orElse(null),
                "a search result titled '" + title + "'");

        // The keyboard can overlay lower results; dismissing it first makes the tap
        // deterministic on smaller screens.
        hideKeyboardIfShown();
        tap(match);
        return new ArticlePage(title);
    }

    public List<String> visibleResultTitles() {
        return resultTitles.stream().map(WebElement::getText).map(String::trim).toList();
    }

    @Override
    protected WebElement uniqueElement() {
        return searchInput;
    }
}
