package com.example.qa.wikipedia.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import java.util.List;

/** The contents of one reading list. */
public class ReadingListDetailPage extends BasePage {

    @AndroidFindBy(id = "org.wikipedia:id/reading_list_recycler_view")
    @iOSXCUITFindBy(className = "XCUIElementTypeTable")
    private WebElement articlesContainer;

    @AndroidFindBy(id = "org.wikipedia:id/page_list_item_title")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCell/**/XCUIElementTypeStaticText[1]")
    private List<WebElement> articleTitles;

    private final String listName;

    public ReadingListDetailPage(String listName) {
        this.listName = listName;
        waitUntilLoaded();
    }

    public String listName() {
        return listName;
    }

    /**
     * @return true if the article is in this list, scrolling the list if necessary
     */
    public boolean containsArticle(String title) {
        if (titlesOnScreen().contains(title)) {
            return true;
        }
        try {
            // A long list may not show the article without scrolling. Failing to find it
            // after a scroll attempt is a real "not saved", not a viewport artefact.
            scrollToText(title);
            return titlesOnScreen().contains(title);
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public List<String> titlesOnScreen() {
        return articleTitles.stream().map(WebElement::getText).map(String::trim).toList();
    }

    @Override
    protected WebElement uniqueElement() {
        return articlesContainer;
    }
}
