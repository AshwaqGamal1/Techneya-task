package com.example.qa.wikipedia.driver;

import io.appium.java_client.AppiumDriver;

/**
 * Holds the session for the current thread.
 *
 * <p>Thread-local rather than a plain static field: the day this suite runs two devices
 * in parallel, a shared static driver would have every test driving the same phone.
 * The cost of doing it correctly now is four lines.
 */
public final class DriverManager {

    private static final ThreadLocal<AppiumDriver> DRIVER = new ThreadLocal<>();

    private DriverManager() {
    }

    public static void startSession() {
        if (DRIVER.get() != null) {
            throw new IllegalStateException("A session is already running on this thread.");
        }
        DRIVER.set(DriverFactory.create());
    }

    public static AppiumDriver driver() {
        AppiumDriver driver = DRIVER.get();
        if (driver == null) {
            throw new IllegalStateException(
                    "No Appium session on this thread. Did the test extend BaseTest?");
        }
        return driver;
    }

    public static boolean hasSession() {
        return DRIVER.get() != null;
    }

    public static void quitSession() {
        AppiumDriver driver = DRIVER.get();
        if (driver != null) {
            try {
                driver.quit();
            } finally {
                // Remove even if quit() threw, or the thread leaks a dead session and
                // every later test on it fails for the wrong reason.
                DRIVER.remove();
            }
        }
    }
}
