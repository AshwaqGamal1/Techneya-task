package com.example.qa.wikipedia.tests;

import com.example.qa.wikipedia.pages.ArticlePage;
import com.example.qa.wikipedia.pages.ExploreFeedPage;
import com.example.qa.wikipedia.pages.OnboardingPage;
import com.example.qa.wikipedia.pages.ReadingListDetailPage;
import com.example.qa.wikipedia.pages.ReadingListsPage;
import com.example.qa.wikipedia.support.BaseTest;
import com.example.qa.wikipedia.support.TestData;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Scenario: save an article to a newly created reading list.
 *
 * <p>The test body is written as the user's journey. Every wait, locator and gesture
 * lives in a page object, so this method stays readable by someone who does not know
 * Appium — and stays unchanged when the app's identifiers move.
 */
public class SaveArticleToReadingListTest extends BaseTest {

    private static final String SEARCH_TERM = "Artificial Intelligence";

    @Test(description = "An article saved into a new reading list appears in that list")
    public void savedArticleAppearsInNewReadingList() {
        String readingListName = TestData.uniqueReadingListName();

        // 1-2. Launch and search.
        ExploreFeedPage feed = new OnboardingPage().skipIfPresent();
        var results = feed.openSearch().searchFor(SEARCH_TERM);

        assertThat(results.visibleResultTitles())
                .as("Search for '%s' should surface the article itself", SEARCH_TERM)
                .anySatisfy(title ->
                        assertThat(title).isEqualToIgnoringCase(TestData.ARTICLE_TITLE));

        // 3-6. Open it, save it, file it into a brand-new list.
        ArticlePage article = results.openResult(TestData.ARTICLE_TITLE);
        article = article.saveAndChooseList()
                .createNewList(readingListName, article.title());

        // 7-8. Reading lists, then find the list that was just created.
        ReadingListsPage readingLists = article.goBackToFeed().openReadingLists();
        readingLists.searchForList(readingListName);

        assertThat(readingLists.visibleListNames())
                .as("The newly created list should be findable by name")
                .contains(readingListName);

        // 9. The article is in it.
        ReadingListDetailPage list = readingLists.openList(readingListName);

        assertThat(list.containsArticle(TestData.ARTICLE_TITLE))
                .as("Article '%s' should be saved in reading list '%s', but the list showed %s",
                        TestData.ARTICLE_TITLE, readingListName, list.titlesOnScreen())
                .isTrue();
    }
}
