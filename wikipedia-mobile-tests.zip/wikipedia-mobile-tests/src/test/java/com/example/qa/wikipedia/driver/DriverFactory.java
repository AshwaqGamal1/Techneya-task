package com.example.qa.wikipedia.driver;

import com.example.qa.wikipedia.config.Config;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.time.Duration;

/**
 * Builds a session for the platform under test.
 *
 * <p>Capabilities are assembled here and nowhere else. Tests and page objects never
 * mention a device, a bundle id or an APK path — swapping emulator for cloud device is
 * a configuration change, not a code change.
 */
public final class DriverFactory {

    private DriverFactory() {
    }

    public static AppiumDriver create() {
        URL server = serverUrl();
        return switch (Config.platform()) {
            case ANDROID -> new AndroidDriver(server, androidOptions());
            case IOS -> new IOSDriver(server, iosOptions());
        };
    }

    private static UiAutomator2Options androidOptions() {
        UiAutomator2Options options = new UiAutomator2Options()
                .setDeviceName(Config.forPlatform("device.name"))
                .setPlatformVersion(Config.forPlatform("platform.version"))
                .setAppPackage(Config.forPlatform("app.package"))
                .setAppActivity(Config.forPlatform("app.activity"))
                .setAutoGrantPermissions(true)
                // A fresh app state per session: the reading list from a previous run
                // must not be able to make the next run pass.
                .setNoReset(false)
                .setNewCommandTimeout(Duration.ofSeconds(120));

        appPath().ifPresent(options::setApp);
        return options;
    }

    private static XCUITestOptions iosOptions() {
        XCUITestOptions options = new XCUITestOptions()
                .setDeviceName(Config.forPlatform("device.name"))
                .setPlatformVersion(Config.forPlatform("platform.version"))
                .setBundleId(Config.forPlatform("bundle.id"))
                .setNoReset(false)
                .setNewCommandTimeout(Duration.ofSeconds(120));

        appPath().ifPresent(options::setApp);
        return options;
    }

    private static java.util.Optional<String> appPath() {
        String configured = Config.forPlatformOrEmpty("app.path");
        if (configured.isBlank()) {
            // No binary configured: run against whatever build is already installed.
            return java.util.Optional.empty();
        }
        Path path = Path.of(configured).toAbsolutePath();
        if (!path.toFile().exists()) {
            throw new IllegalStateException("Configured app binary does not exist: " + path);
        }
        return java.util.Optional.of(path.toString());
    }

    private static URL serverUrl() {
        try {
            return new URL(Config.appiumServerUrl());
        } catch (MalformedURLException e) {
            throw new IllegalStateException(
                    "Invalid Appium server URL: " + Config.appiumServerUrl(), e);
        }
    }
}
