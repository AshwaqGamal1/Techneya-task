package com.example.qa.wikipedia.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;

import java.util.List;

/** The Saved tab: the collection of reading lists. */
public class ReadingListsPage extends BasePage {

    @AndroidFindBy(id = "org.wikipedia:id/recycler_view")
    @iOSXCUITFindBy(className = "XCUIElementTypeTable")
    private WebElement listsContainer;

    @AndroidFindBy(accessibility = "Search reading lists")
    @iOSXCUITFindBy(accessibility = "Search reading lists")
    private WebElement searchListsButton;

    @AndroidFindBy(id = "org.wikipedia:id/search_src_text")
    @iOSXCUITFindBy(className = "XCUIElementTypeSearchField")
    private WebElement searchInput;

    @AndroidFindBy(id = "org.wikipedia:id/item_title")
    @iOSXCUITFindBy(iOSClassChain = "**/XCUIElementTypeCell/**/XCUIElementTypeStaticText[1]")
    private List<WebElement> listTitles;

    public ReadingListsPage() {
        waitUntilLoaded();
    }

    public ReadingListsPage searchForList(String name) {
        if (isDisplayed(searchListsButton)) {
            tap(searchListsButton);
        }
        type(searchInput, name);
        hideKeyboardIfShown();
        waitFor(d -> listTitles.stream().anyMatch(e -> name.equals(e.getText().trim())),
                "a reading list named '" + name + "' in the search results");
        return this;
    }

    public List<String> visibleListNames() {
        return listTitles.stream().map(WebElement::getText).map(String::trim).toList();
    }

    public ReadingListDetailPage openList(String name) {
        WebElement match = waitFor(
                d -> listTitles.stream()
                        .filter(e -> name.equals(e.getText().trim()))
                        .findFirst()
                        .orElse(null),
                "reading list '" + name + "'");
        tap(match);
        return new ReadingListDetailPage(name);
    }

    @Override
    protected WebElement uniqueElement() {
        return listsContainer;
    }
}
